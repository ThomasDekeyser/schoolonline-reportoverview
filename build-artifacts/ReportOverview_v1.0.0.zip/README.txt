Hoofd functies
-functie 1: rapport-data voor ��n welbepaalde klas van bsvisitatie.schoolonline.be te halen en offline te bewaren
Systeemvereisten: Java Runtime environment ge�nstalleerd. http://java.com/en/download/index.jsp

- functie 2: deze data offline leesbaar maken via standaard webbrowser 
Systeemvereisten: moderne webbrowser (getest op IE9,Firefox 17,Chrome)


Configuratie:
Gebruikersnaam en paswoord plaatsen in file lib/schoolOnlineBe.xml via eenvoudige teksteditor (bv MS notepad, beter NIET via MS Word)

Release notes
=========================================================================================
v1.0.0 (2013/02/09)
* Rapport resultaten
* "Toon/Verberg commentaar" knop
* Punten onder de helf staan in het rood
* Commentaar beschikbaar via tooltip
* Navigatie door tabs via op/neer (of links/rechts) pijltjes

Known issues:
* Letters met accenten (�,�,...) worden niet goed afgebeeld.
=========================================================================================
